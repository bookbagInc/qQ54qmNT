jcsalter
COS 429 Assignment 2 README

Part II:

My sample graphs were computed with 4000 training images, 500 test images, 30 orientations,
and wrap180 = true.

1. What happens to performance on the training set as the number of training images 
increases? If at some point you don't get perfect training performance any more, why not?

As the number of training images increases, the training performance decreases. However,
this can be counteracted by increasing the number of orientations. For example, using 2100
images and only 4 orientations yielded very imperfect results, but using the same number of
images and 12 orientations did yield perfect results. On the max of 6000 images, I tried 
using 80 orientations, and the results were not terrible but still not perfect. If I kept 
increasing this number of orientations to maybe 100 or more, I would have eventually achieved 
perfect results. This imperfection in training performance, then, can be explained by the
more varying types and orientations of faces as more and more faces are read in. If you do
not account for these increasing variations by increasing the number of orientations, the
training results will be imperfect.


2. What happens to performance on the test set as the number of training images increases?

Performance on the test set gets better as the number of training images increases only if
the number of orientations is increased as well. This is because you want the trainer to be
as close to perfect as possible, but if you increase the number training images without
increasing orientations, the trainer is imperfect and it does not help the test images.

3. What happens to performance on the test set as the number of orientations increases?

Everything else constant, increasing the number of orientations only minorly improves the
performance on the test set. It does, however, vastly improve the performance on the
training set.


4. Do you see the same behavior as Dalal and Triggs, in that turning off the wrapping of 
orientations at 180 degrees makes little difference to performance? If not (e.g., not 
wrapping is better), can you hypothesize why?

Yes, I saw the same behavior as Dalal and Triggs--turning of the wrapping of orientations
made very little difference.


5. In parts III and IV of this assignment, you will run this detector at many locations 
throughout an image that may or may not contain some faces. Would you prefer to run the 
detector with a threshold that favors fewer false positives, fewer false negatives, or 
some balance? Why?

I would like a balance that is skewed towards having more false negatives. This is because I'd
rather miss a face or two in an image and not detect any nonfaces, rather than detect every
face but a ton of nonfaces along with it. In this way, my face detector would pick up most
faces, just not the faded or obscure ones, and it would rarely detect a nonface. Then, the
user of whatever application I built can manually select the one or two faces that are not
detected if need be. 



Part III:

The single scale detector detects false positives in places where the histogram of gradients 
would result in a similar plot that would result from a face. These are area with multiple
changes in intensity and gradient direction. For example, a knee with some 
blotches on it, or part of someones shirt with some wrinkles in it. This is especially true
when the image is particularly faded or lacking quality, because parts of the image blend
together and it is difficult to discern between what is a face and what is not. 
False negatives--faces that should be detected but are not--occur when the face is turned away
from the camera or the face is very faded such that the facial features are hard to pick up.
Also, if there is a shadow covering part of the face, or accessories like sunglasses and 
facial hair, there was a better chance of it not being detected. 
For the most part, though, just about all faces that were facing towards the camera and clearly
discernible from their backgrounds were picked up. 



Part IV:

This discussion is the same as it was for Part III because the same facial detector was used. We
can just apply the analysis across multiple scales. So, false positives were detected in locations
of arbitrary size, not just 36x36, that had features similar to a face. As a result, without
performing nonmaximum suppression, there were a lot more false positives here than there were
in the single scale detection. Areas like knees, shirt sleeves, and the space between two peopls arms 
were sometimes detected. These are all areas with multiple changes in intensity and gradient
direction.
False negatives occurred in the same situations as the single scale--when something was obstructing
the face in some way. This could be the direction the face was looking, facial accessories, or
general blurriness. Now, however, the detector could pick up faces that were larger than 36x36; it
missed these in the single scale because that only checked for faces of that exact size.




