%
% Princeton University, COS 429, Fall 2016
%
% find_faces.m
%   Find faces in an image
%
% Inputs:
%   img: an image
%   stride: how far to move between locations at which the detector is run,
%       at the finest (36x36) scale.  This is effectively scaled up for
%       larger windows.
%   thresh: probability threshold for calling a detection a face
%   params: trained face classifier parameters
%   orientations: the number of HoG gradient orientations to use
%   wrap180: if true, the HoG orientations cover 180 degrees, else 360
% Outputs:
%   outimg: copy of img with face locations marked
%

function outimg = find_faces(img, stride, thresh, ...
        params, orientations, wrap180)

    % Fill in here
    hog_descriptor_size = 100 * orientations;
    hog_input_size = 36;
    windowsize = 36;
    
    if stride > windowsize
        stride = windowsize;
    end

    stride_ratio = stride / windowsize;
    
    [height width] = size(img);
    outimg = img;
    
    descriptor = zeros(1, hog_descriptor_size + 1);

    % While windowsize is less than minimum dimension of the image
    min_dimension = min(height, width);
    while (windowsize <= min_dimension)
        
    % Loop over windowsize x windowsize windows, advancing by stride
        for i = 1 : stride : height - windowsize
            for j = 1 : stride : width - windowsize

                % Crop out a windowsize x windowsize window starting at (i,j)
                crop = img(i : i+windowsize-1, j : j+windowsize-1);
                crop = imresize(crop, [hog_input_size hog_input_size]);
                
                % Compute a HoG descriptor, and run the classifier
                hog_descriptor = hog36(crop, orientations, wrap180);
                descriptor(1,1) = 1;
                descriptor(1,2:hog_descriptor_size+1) = hog_descriptor;

                probability = logistic_prob(descriptor, params);
                
                % If probability of a face is below thresh, continue
                if probability < thresh
                    continue;
                end

                % Mark the face in outimg
                outimg(i, j:j+windowsize-1) = 255;
                outimg(i+windowsize-1, j:j+windowsize-1) = 255;
                outimg(i:i+windowsize-1, j) = 255;
                outimg(i:i+windowsize-1, j+windowsize-1) = 255;
            end
        end
        % Increase windowsize by 20%
        windowsize = ceil(windowsize * 1.2);
        
        % Increase stride by the correct ratio of the windowsize
        stride = ceil(stride_ratio * windowsize);
    end
end
