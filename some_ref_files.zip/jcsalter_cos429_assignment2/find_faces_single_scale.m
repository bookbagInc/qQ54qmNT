%
% Princeton University, COS 429, Fall 2016
%
% find_faces_single_scale.m
%   Find 36x36 faces in an image
%
% Inputs:
%   img: an image
%   stride: how far to move between locations at which the detector is run
%   thresh: probability threshold for calling a detection a face
%   params: trained face classifier parameters
%   orientations: the number of HoG gradient orientations to use
%   wrap180: if true, the HoG orientations cover 180 degrees, else 360
% Outputs:
%   outimg: copy of img with face locations marked
%   probmap: probability map of face detections
%

function [outimg probmap] = find_faces_single_scale(img, stride, thresh, ...
        params, orientations, wrap180)

    hog_descriptor_size = 100 * orientations;
    windowsize = 36;
    
    if stride > windowsize
        stride = windowsize;
    end

    [height width] = size(img);
    probmap = zeros(height, width);
    outimg = img;

    descriptor = zeros(1, hog_descriptor_size + 1);

    % Loop over windowsize x windowsize windows, advancing by stride
    for i = 1 : stride : height - windowsize
        for j = 1 : stride : width - windowsize
            
            % Crop out a windowsize x windowsize window starting at (i,j)
             crop = img(i : i+windowsize-1, j : j+windowsize-1);

            % Compute a HoG descriptor, and run the classifier
            hog_descriptor = hog36(crop, orientations, wrap180);
            descriptor(1,1) = 1;
            descriptor(1,2:hog_descriptor_size+1) = hog_descriptor;
        
            probability = logistic_prob(descriptor, params);

            % Mark detection probability in probmap
            win_i = i + floor((windowsize - stride) / 2);
            win_j = j + floor((windowsize - stride) / 2);
            probmap(win_i:win_i+stride-1, win_j:win_j+stride-1) = probability;

            % If probability of a face is below thresh, continue
            if probability < thresh
                continue;
            end

            % Mark the face in outimg
            outimg(i, j:j+windowsize-1) = 255;
            outimg(i+windowsize-1, j:j+windowsize-1) = 255;
            outimg(i:i+windowsize-1, j) = 255;
            outimg(i:i+windowsize-1, j+windowsize-1) = 255;
        end
    end
end
