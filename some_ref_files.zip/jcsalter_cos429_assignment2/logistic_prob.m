%
% Princeton University, COS 429, Fall 2016
%
% logistic_prob.m
%   Given a logistic model and some new data, predicts probability that
%   the class is 1.
%
% Inputs:
%   X: datapoints (one per row, should include a column of ones
%                  if the model is to have a constant)
%   params: vector of parameters 
% Output:
%   z: predicted probabilities (0..1)
%

function z = logistic_prob(X, params)

    % Fill in here
    z = logistic(X * params)';
end

function val = logistic(x)
    [m,n] = size(x);
    val = zeros(1,m);
    for i = 1 : m
        val(1,i) = 1 / (1 + exp(-x(i)));
    end
end
